#include "E2EDemo.h"
#include <memory>

int DLLCALL E2E_Calculate(unsigned int canID, unsigned int dataID, unsigned int *counter, const unsigned char* rawData, unsigned int rawDataLen,
						  unsigned char* outData, unsigned int outDataSize)
{
	if (rawDataLen < 2 || outDataSize < rawDataLen) {
		return 0;
	}

	memcpy(outData, rawData, rawDataLen);
	outData[1] = *counter;

	*counter += 2;

	unsigned char crc = dataID & 0xFF;
	for (unsigned int i = 1; i < rawDataLen; i++) {
		crc += outData[i];
	}

	outData[0] = crc;

	return rawDataLen;
}
